</main>

</div>

<footer class="site-footer">
    <p>
        © <?php echo date("Y"); ?> Ibrahimx —
        Smart Job Application Tracker by
        <strong>Md Ibrahim Khalil</strong>
        |
        <a href="https://www.ibrahimx.com" target="_blank">www.ibrahimx.com</a>
    </p>
</footer>

</body>
</html>