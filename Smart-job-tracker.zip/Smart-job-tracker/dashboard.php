<?php require_once "includes/interview_reminders.php"; ?>
<?php
require_once "includes/auth_check.php";
require_once "config/database.php";
require_once "includes/header.php";
require_once "includes/sidebar.php";


$user_id = $_SESSION["user_id"];

// Total jobs
$stmt = $pdo->prepare("SELECT COUNT(*) FROM jobs WHERE user_id = ?");
$stmt->execute([$user_id]);
$totalJobs = $stmt->fetchColumn();

// Applied
$stmt = $pdo->prepare("SELECT COUNT(*) FROM jobs WHERE user_id = ? AND status = 'Applied'");
$stmt->execute([$user_id]);
$appliedJobs = $stmt->fetchColumn();

// Interviews
$stmt = $pdo->prepare("SELECT COUNT(*) FROM jobs WHERE user_id = ? AND status = 'Interview'");
$stmt->execute([$user_id]);
$interviewJobs = $stmt->fetchColumn();

// Offers
$stmt = $pdo->prepare("SELECT COUNT(*) FROM jobs WHERE user_id = ? AND status = 'Offer'");
$stmt->execute([$user_id]);
$offerJobs = $stmt->fetchColumn();

// Rejected
$stmt = $pdo->prepare("SELECT COUNT(*) FROM jobs WHERE user_id = ? AND status = 'Rejected'");
$stmt->execute([$user_id]);
$rejectedJobs = $stmt->fetchColumn();

// Accepted
$stmt = $pdo->prepare("SELECT COUNT(*) FROM jobs WHERE user_id = ? AND status = 'Accepted'");
$stmt->execute([$user_id]);
$acceptedJobs = $stmt->fetchColumn();

// Recent jobs
$stmt = $pdo->prepare("SELECT * FROM jobs WHERE user_id = ? ORDER BY created_at DESC LIMIT 5");
$stmt->execute([$user_id]);
$recentJobs = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Upcoming interviews
$stmt = $pdo->prepare("
    SELECT * FROM jobs 
    WHERE user_id = ? 
    AND interview_date IS NOT NULL 
    AND interview_date >= CURDATE()
    ORDER BY interview_date ASC 
    LIMIT 5
");
$stmt->execute([$user_id]);
$upcomingInterviews = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="page-header">
    <h1>Dashboard</h1>
    <p>Welcome back, <?= htmlspecialchars($_SESSION["user_name"]); ?> 👋</p>
</div>

<?php require_once "includes/interview_reminders.php"; ?>

<div class="stats-grid">
    <div class="stat-card">
        <h3>Total Applications</h3>
        <p><?= $totalJobs; ?></p>
    </div>

    <div class="stat-card">
        <h3>Applied</h3>
        <p><?= $appliedJobs; ?></p>
    </div>

    <div class="stat-card">
        <h3>Interviews</h3>
        <p><?= $interviewJobs; ?></p>
    </div>

    <div class="stat-card">
        <h3>Offers</h3>
        <p><?= $offerJobs; ?></p>
    </div>

    <div class="stat-card danger">
        <h3>Rejected</h3>
        <p><?= $rejectedJobs; ?></p>
    </div>
</div>

<div class="content-card chart-card">
    <div class="card-header">
        <h2>Applications by Status</h2>
    </div>

    <canvas id="statusChart"></canvas>
</div>

<div class="dashboard-grid">
    <div class="content-card">
        <div class="card-header">
            <h2>Recent Applications</h2>
            <a href="jobs/view.php" class="small-btn">View All</a>
        </div>

        <?php if (count($recentJobs) > 0): ?>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Company</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentJobs as $job): ?>
                        <tr>
                            <td><?= htmlspecialchars($job["company"]); ?></td>
                            <td><?= htmlspecialchars($job["role"]); ?></td>
                            <td>
                                <span class="status-badge <?= strtolower($job["status"]); ?>">
                                    <?= htmlspecialchars($job["status"]); ?>
                                </span>
                            </td>
                            <td><?= date("d M Y", strtotime($job["created_at"])); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="empty-message">No applications added yet.</p>
            <a href="jobs/add.php" class="btn">Add Your First Job</a>
        <?php endif; ?>
    </div>

    <div class="content-card">
        <div class="card-header">
            <h2>Upcoming Interviews</h2>
        </div>

        <?php if (count($upcomingInterviews) > 0): ?>
            <?php foreach ($upcomingInterviews as $interview): ?>
                <div class="interview-item">
                    <h3><?= htmlspecialchars($interview["company"]); ?></h3>
                    <p><?= htmlspecialchars($interview["role"]); ?></p>
                    <strong><?= date("d M Y", strtotime($interview["interview_date"])); ?></strong>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="empty-message">No upcoming interviews.</p>
        <?php endif; ?>
    </div>
</div>

<script>
const ctx = document.getElementById('statusChart');

new Chart(ctx, {
    type: 'doughnut',
    data: {
        labels: ['Applied', 'Interview', 'Offer', 'Rejected', 'Accepted'],
        datasets: [{
            data: [
                <?= $appliedJobs; ?>,
                <?= $interviewJobs; ?>,
                <?= $offerJobs; ?>,
                <?= $rejectedJobs; ?>,
                <?= $acceptedJobs; ?>
            ],
            backgroundColor: [
                '#2563eb',
                '#f59e0b',
                '#16a34a',
                '#dc2626',
                '#059669'
            ],
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'bottom'
            }
        }
    }
});
</script>

