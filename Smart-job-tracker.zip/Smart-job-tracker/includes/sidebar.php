<aside class="sidebar">
    <div class="sidebar-brand">
        <h3>Ibrahimx</h3>
        <p>Job Tracker</p>
    </div>

    <nav class="sidebar-menu">
        <a href="/smart-job-tracker/dashboard.php">Dashboard</a>
        <a href="/smart-job-tracker/jobs/view.php">Applications</a>
        <a href="/smart-job-tracker/jobs/add.php">Add Job</a>
        <a href="/smart-job-tracker/jobs/view.php?status=Interview">Interviews</a>
        <a href="/smart-job-tracker/auth/logout.php" class="sidebar-logout">Logout</a>
    </nav>

    <div class="sidebar-footer">
        <p>Built by</p>
        <strong>Md Ibrahim Khalil</strong>
        <a href="https://www.ibrahimx.com" target="_blank">www.ibrahimx.com</a>
    </div>
</aside>

<main class="main-content">