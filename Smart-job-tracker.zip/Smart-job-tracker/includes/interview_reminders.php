<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . "/../config/database.php";

if (!isset($_SESSION["user_id"])) {
    return;
}

$user_id = $_SESSION["user_id"];

$stmt = $pdo->prepare("
    SELECT * FROM jobs
    WHERE user_id = ?
    AND interview_date IS NOT NULL
    AND interview_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 3 DAY)
    ORDER BY interview_date ASC
");

$stmt->execute([$user_id]);
$reminders = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<?php if (count($reminders) > 0): ?>
    <div class="reminder-box">
        <h3>Upcoming Interview Reminders</h3>

        <?php foreach ($reminders as $reminder): ?>
            <div class="reminder-item">
                <strong><?= htmlspecialchars($reminder["company"]); ?></strong>
                <span><?= htmlspecialchars($reminder["role"]); ?></span>
                <small>
                    Interview Date:
                    <?= date("d M Y", strtotime($reminder["interview_date"])); ?>
                </small>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>