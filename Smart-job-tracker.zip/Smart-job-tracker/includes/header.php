<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$userName = $_SESSION["user_name"] ?? "User";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Ibrahimx | Smart Job Application Tracker</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="/smart-job-tracker/assets/css/style.css">
</head>
<body>

<div class="app-layout">

<header class="top-header">
    <div>
        <h2>Ibrahimx</h2>
        <p>Smart Job Application Tracker</p>
    </div>

    <div class="header-user">
        <span>Hello, <?= htmlspecialchars($userName); ?></span>
        <a href="/smart-job-tracker/auth/logout.php" class="logout-btn">Logout</a>
    </div>
</header>