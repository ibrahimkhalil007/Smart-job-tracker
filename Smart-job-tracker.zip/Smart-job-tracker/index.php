<?php
session_start();

if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Ibrahimx | Smart Job Application Tracker</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<div class="home-container">
    <div class="home-card">
        <h1>Ibrahimx</h1>
        <h2>Smart Job Application Tracker</h2>
        <p>
            A portfolio project by <strong>Md Ibrahim Khalil</strong>.
            Track your job applications, interviews, salaries, statuses, and notes in one place.
        </p>

        <div class="home-buttons">
            <a href="auth/login.php" class="btn">Login</a>
            <a href="auth/register.php" class="btn btn-outline">Create Account</a>
        </div>

        <p class="portfolio-link">
            Portfolio: <a href="https://www.ibrahimx.com" target="_blank">www.ibrahimx.com</a>
        </p>
    </div>
</div>

</body>
</html>