<?php
require_once "../includes/auth_check.php";
require_once "../config/database.php";

$user_id = $_SESSION["user_id"];
$job_id = $_GET["id"] ?? null;

if (!$job_id) {
    header("Location: view.php");
    exit;
}

$stmt = $pdo->prepare("DELETE FROM jobs WHERE id = ? AND user_id = ?");
$stmt->execute([$job_id, $user_id]);

header("Location: view.php");
exit;