<?php
require_once "../includes/auth_check.php";
require_once "../config/database.php";
require_once "../includes/header.php";
require_once "../includes/sidebar.php";

$user_id = $_SESSION["user_id"];
$job_id = $_GET["id"] ?? null;

if (!$job_id) {
    header("Location: view.php");
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM jobs WHERE id = ? AND user_id = ?");
$stmt->execute([$job_id, $user_id]);
$job = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$job) {
    header("Location: view.php");
    exit;
}
?>

<div class="page-header">
    <h1>Application Details</h1>
    <p>View full details of this job application.</p>
</div>

<div class="details-card">
    <div class="details-header">
        <div>
            <h2><?= htmlspecialchars($job["company"]); ?></h2>
            <p><?= htmlspecialchars($job["role"]); ?></p>
        </div>

        <span class="status-badge <?= strtolower($job["status"]); ?>">
            <?= htmlspecialchars($job["status"]); ?>
        </span>
    </div>

    <div class="details-grid">
        <div class="details-item">
            <strong>Company</strong>
            <p><?= htmlspecialchars($job["company"]); ?></p>
        </div>

        <div class="details-item">
            <strong>Role</strong>
            <p><?= htmlspecialchars($job["role"]); ?></p>
        </div>

        <div class="details-item">
            <strong>Salary</strong>
            <p><?= htmlspecialchars($job["salary"] ?: "N/A"); ?></p>
        </div>

        <div class="details-item">
            <strong>Interview Date</strong>
            <p>
                <?= !empty($job["interview_date"]) 
                    ? date("d M Y", strtotime($job["interview_date"])) 
                    : "N/A"; 
                ?>
            </p>
        </div>

        <div class="details-item">
            <strong>Applied Date</strong>
            <p><?= date("d M Y", strtotime($job["created_at"])); ?></p>
        </div>
    </div>

    <div class="details-notes">
        <strong>Notes</strong>
        <p>
            <?= !empty($job["notes"]) 
                ? nl2br(htmlspecialchars($job["notes"])) 
                : "No notes added."; 
            ?>
        </p>
    </div>

    <div class="form-actions">
        <a href="edit.php?id=<?= $job["id"]; ?>" class="btn">Edit Application</a>
        <a href="view.php" class="btn btn-outline">Back to Applications</a>
    </div>
</div>

