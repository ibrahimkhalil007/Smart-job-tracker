<?php
require_once "../includes/auth_check.php";
require_once "../config/database.php";
require_once "../includes/header.php";
require_once "../includes/sidebar.php";

$user_id = $_SESSION["user_id"];
$job_id = $_GET["id"] ?? null;

if (!$job_id) {
    header("Location: view.php");
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM jobs WHERE id = ? AND user_id = ?");
$stmt->execute([$job_id, $user_id]);
$job = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$job) {
    header("Location: view.php");
    exit;
}

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $company = trim($_POST["company"]);
    $role = trim($_POST["role"]);
    $salary = trim($_POST["salary"]);
    $status = $_POST["status"];
    $interview_date = !empty($_POST["interview_date"]) ? $_POST["interview_date"] : null;
    $notes = trim($_POST["notes"]);

    if (empty($company) || empty($role)) {
        $error = "Company and role are required.";
    } else {
        $stmt = $pdo->prepare("
            UPDATE jobs 
            SET company = ?, role = ?, salary = ?, status = ?, interview_date = ?, notes = ?
            WHERE id = ? AND user_id = ?
        ");

        $stmt->execute([
            $company,
            $role,
            $salary,
            $status,
            $interview_date,
            $notes,
            $job_id,
            $user_id
        ]);

        $success = "Job application updated successfully.";

        $stmt = $pdo->prepare("SELECT * FROM jobs WHERE id = ? AND user_id = ?");
        $stmt->execute([$job_id, $user_id]);
        $job = $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
?>

<div class="page-header">
    <h1>Edit Application</h1>
    <p>Update your job application details.</p>
</div>

<div class="form-card">
    <?php if (!empty($error)): ?>
        <div class="error"><?= htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <?php if (!empty($success)): ?>
        <div class="success"><?= htmlspecialchars($success); ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-grid">
            <div class="form-group">
                <label>Company Name *</label>
                <input 
                    type="text" 
                    name="company" 
                    value="<?= htmlspecialchars($job["company"]); ?>" 
                    required
                >
            </div>

            <div class="form-group">
                <label>Job Role *</label>
                <input 
                    type="text" 
                    name="role" 
                    value="<?= htmlspecialchars($job["role"]); ?>" 
                    required
                >
            </div>

            <div class="form-group">
                <label>Salary</label>
                <input 
                    type="text" 
                    name="salary" 
                    value="<?= htmlspecialchars($job["salary"]); ?>"
                >
            </div>

            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="Applied" <?= $job["status"] === "Applied" ? "selected" : ""; ?>>Applied</option>
                    <option value="Interview" <?= $job["status"] === "Interview" ? "selected" : ""; ?>>Interview</option>
                    <option value="Offer" <?= $job["status"] === "Offer" ? "selected" : ""; ?>>Offer</option>
                    <option value="Rejected" <?= $job["status"] === "Rejected" ? "selected" : ""; ?>>Rejected</option>
                    <option value="Accepted" <?= $job["status"] === "Accepted" ? "selected" : ""; ?>>Accepted</option>
                </select>
            </div>

            <div class="form-group">
                <label>Interview Date</label>
                <input 
                    type="date" 
                    name="interview_date" 
                    value="<?= htmlspecialchars($job["interview_date"]); ?>"
                >
            </div>
        </div>

        <div class="form-group">
            <label>Notes</label>
            <textarea name="notes"><?= htmlspecialchars($job["notes"]); ?></textarea>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn">Update Application</button>
            <a href="details.php?id=<?= $job["id"]; ?>" class="btn btn-outline">View Details</a>
            <a href="view.php" class="btn btn-outline">Back</a>
        </div>
    </form>
</div>

