<?php
require_once "../includes/auth_check.php";
require_once "../config/database.php";
require_once "../includes/header.php";
require_once "../includes/sidebar.php";

$user_id = $_SESSION["user_id"];

$search = $_GET["search"] ?? "";
$status = $_GET["status"] ?? "";

$sql = "SELECT * FROM jobs WHERE user_id = ?";
$params = [$user_id];

if (!empty($search)) {
    $sql .= " AND (company LIKE ? OR role LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (!empty($status)) {
    $sql .= " AND status = ?";
    $params[] = $status;
}

$sql .= " ORDER BY created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="page-header">
    <h1>All Applications</h1>
    <p>Search, filter, edit, and manage your job applications.</p>
</div>

<div class="content-card">
    <form method="GET" class="filter-form">
        <input 
            type="text" 
            name="search" 
            placeholder="Search company or role..."
            value="<?= htmlspecialchars($search); ?>"
        >

        <select name="status">
            <option value="">All Status</option>
            <option value="Applied" <?= $status === "Applied" ? "selected" : ""; ?>>Applied</option>
            <option value="Interview" <?= $status === "Interview" ? "selected" : ""; ?>>Interview</option>
            <option value="Offer" <?= $status === "Offer" ? "selected" : ""; ?>>Offer</option>
            <option value="Rejected" <?= $status === "Rejected" ? "selected" : ""; ?>>Rejected</option>
            <option value="Accepted" <?= $status === "Accepted" ? "selected" : ""; ?>>Accepted</option>
        </select>

        <button type="submit" class="small-btn">Filter</button>
        <a href="view.php" class="reset-btn">Reset</a>
        <a href="add.php" class="small-btn">Add New</a>
    </form>

    <?php if (count($jobs) > 0): ?>
        <table class="data-table">
            <thead>
                <tr>
                    <th>Company</th>
                    <th>Role</th>
                    <th>Salary</th>
                    <th>Status</th>
                    <th>Interview</th>
                    <th>Applied Date</th>
                    <th>Actions</th>
                </tr>
            </thead>

            <tbody>
                <?php foreach ($jobs as $job): ?>
                    <tr>
                        <td><?= htmlspecialchars($job["company"]); ?></td>
                        <td><?= htmlspecialchars($job["role"]); ?></td>
                        <td><?= htmlspecialchars($job["salary"] ?: "N/A"); ?></td>
                        <td>
                            <span class="status-badge <?= strtolower($job["status"]); ?>">
                                <?= htmlspecialchars($job["status"]); ?>
                            </span>
                        </td>
                        <td>
                            <?= !empty($job["interview_date"]) 
                                ? date("d M Y", strtotime($job["interview_date"])) 
                                : "N/A"; 
                            ?>
                        </td>
                        <td><?= date("d M Y", strtotime($job["created_at"])); ?></td>
                        <td>
                            <div class="action-buttons">
                                <a href="details.php?id=<?= $job["id"]; ?>" class="view-btn">View</a>
                                <a href="edit.php?id=<?= $job["id"]; ?>" class="edit-btn">Edit</a>
                                <a 
                                    href="delete.php?id=<?= $job["id"]; ?>" 
                                    class="delete-btn"
                                    onclick="return confirm('Are you sure you want to delete this application?');"
                                >
                                    Delete
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="empty-message">No job applications found.</p>
        <a href="add.php" class="btn">Add Job Application</a>
    <?php endif; ?>
</div>

