<?php
require_once "../includes/auth_check.php";
require_once "../config/database.php";
require_once "../includes/header.php";
require_once "../includes/sidebar.php";

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $company = trim($_POST["company"]);
    $role = trim($_POST["role"]);
    $salary = trim($_POST["salary"]);
    $status = $_POST["status"];
    $interview_date = !empty($_POST["interview_date"]) ? $_POST["interview_date"] : null;
    $notes = trim($_POST["notes"]);

    if (empty($company) || empty($role)) {
        $error = "Company and role are required.";
    } else {
        $stmt = $pdo->prepare("
            INSERT INTO jobs 
            (user_id, company, role, salary, status, interview_date, notes) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $_SESSION["user_id"],
            $company,
            $role,
            $salary,
            $status,
            $interview_date,
            $notes
        ]);

        $success = "Job application added successfully.";
    }
}
?>

<div class="page-header">
    <h1>Add Job Application</h1>
    <p>Add a new job application to your Ibrahimx tracker.</p>
</div>

<div class="form-card">
    <?php if (!empty($error)): ?>
        <div class="error"><?= htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <?php if (!empty($success)): ?>
        <div class="success"><?= htmlspecialchars($success); ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-grid">
            <div class="form-group">
                <label>Company Name *</label>
                <input type="text" name="company" placeholder="Example: Google" required>
            </div>

            <div class="form-group">
                <label>Job Role *</label>
                <input type="text" name="role" placeholder="Example: PHP Developer" required>
            </div>

            <div class="form-group">
                <label>Salary</label>
                <input type="text" name="salary" placeholder="Example: €45,000">
            </div>

            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="Applied">Applied</option>
                    <option value="Interview">Interview</option>
                    <option value="Offer">Offer</option>
                    <option value="Rejected">Rejected</option>
                    <option value="Accepted">Accepted</option>
                </select>
            </div>

            <div class="form-group">
                <label>Interview Date</label>
                <input type="date" name="interview_date">
            </div>
        </div>

        <div class="form-group">
            <label>Notes</label>
            <textarea name="notes" placeholder="Write notes about this job application..."></textarea>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn">Save Application</button>
            <a href="view.php" class="btn btn-outline">View Applications</a>
        </div>
    </form>
</div>

